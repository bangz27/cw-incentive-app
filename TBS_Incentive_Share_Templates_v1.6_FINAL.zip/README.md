# TBS Incentive Share Story Templates v1.6

Production artwork pack for importing into the TBS Incentive Share Story feature.

## Artwork files

- `01_TBS_Incentive_Orange_City_Ride.png` — motorbike urban delivery and orange city energy
- `02_TBS_Incentive_Scenic_Highway.png` — motorbike on a mountain and coastal scenic highway
- `03_TBS_Incentive_Night_Hub.png` — 4W logistics truck at a neon night hub
- `04_TBS_Incentive_Warehouse_Box.png` — warehouse, conveyor, sorting and parcel boxes
- `05_TBS_Incentive_Sky_Victory.png` — rider achievement with blue sky and city skyline

## Production specification

Each artwork is a standalone full-page PNG at **1080 × 1920 px**, aspect ratio **9:16**. The files are independent artworks, not a composite, screenshot, crop from a composite, or overlay of another template.

The three and only three dynamic fields that the future runtime may render are **Date**, **Parcel Count**, and **Vehicle (2W/4W)**. The artwork contains clean design areas for these values but does not contain sample dynamic values, dates, placeholder syntax, or personal data.

The following hashtags are already embedded in each artwork and must not be rendered again by the Renderer: `#TBSIncentive`, `#วันนี้วิ่งไป`, `#งานวันนี้`, and `#SPXExpress`.

Do not render financial or personal information in a Share Story image. This includes money, Gross, Net, Deduction, Rate, Tier, Zone, RTS, Driver ID, Employee ID, Email, and other private data.
