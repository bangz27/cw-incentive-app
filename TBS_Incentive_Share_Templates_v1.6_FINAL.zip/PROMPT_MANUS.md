# Manus Runtime Contract for TBS Incentive Share Story

Use one PNG file per Template. Do not combine the five artworks, crop a composite, use a screenshot, or use an image preview as a production source.

The runtime pipeline is:

`one template PNG → one Canvas/Bitmap → draw Date, Parcel Count, and Vehicle only → export one PNG`

The runtime must not place a second copy of the template, a card, a rectangle, an image overlay, or any other panel over the artwork. The clean artwork areas are reserved for the three allowed dynamic values.

The four hashtags are already embedded in each artwork. Do not render or append hashtags from JavaScript. Do not add money, Gross, Net, Deduction, Rate, Tier, Zone, RTS, Driver ID, Employee ID, Email, or any personal information to the share image.

Preserve each artwork's complete 1080 × 1920, 9:16 composition. The five visual concepts are intentionally different: Orange City Ride, Scenic Highway, Night Hub, Warehouse Box, and Sky Victory.
